<div class="footer">
    <p>&copy; <?php echo e(date('Y')); ?> Ardy Iksan Maulana. Semua Hak Dilindungi.</p>
    <p>
        <a href="<?php echo e(route('kontak.index')); ?>" style="color: #007bff; text-decoration: none;">Hubungi Saya</a>
    </p>
</div><?php /**PATH C:\laragon\www\ardy\resources\views/components/footer.blade.php ENDPATH**/ ?>