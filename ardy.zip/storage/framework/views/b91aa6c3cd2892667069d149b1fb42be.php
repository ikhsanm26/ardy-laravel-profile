

<?php $__env->startSection('content'); ?>
<div class="container mt-5" style="max-width: 700px;">
    <div class="card shadow">
        <div class="card-body">
            <h3 class="text-center mb-4">Tambah Data Mahasiswa</h3>
            
            
            
            <form action="<?php echo e(route('insertdata')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                
                <div class="mb-3">
                    <label class="form-label fw-bold">NIM</label>
                    <input type="text" name="nim" class="form-control" placeholder="Masukkan NIM">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama Lengkap">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Jurusan</label>
                    <input type="text" name="jurusan" class="form-control" placeholder="Masukkan Jurusan">
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                    
                    <a href="<?php echo e(route('mahasiswa')); ?>" class="btn btn-secondary">Batal / Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ardy\resources\views/mahasiswa/tambahmahasiswa.blade.php ENDPATH**/ ?>