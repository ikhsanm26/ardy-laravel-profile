

<?php $__env->startSection('title', $post['judul']); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="max-width: 800px; margin: 0 auto; padding-top: 20px;">
        
        <a href="<?php echo e(route('berita.index')); ?>" style="display: block; margin-bottom: 20px; color: #007bff; text-decoration: none; font-weight: bold;">&larr; Kembali ke Daftar Berita</a>
        
        <h1 style="margin-bottom: 10px; color: #333;"><?php echo e($post['judul']); ?></h1>
        <p style="font-size: 0.9em; color: #777; border-bottom: 1px solid #eee; padding-bottom: 10px;">
            Ditulis oleh <?php echo e($post['penulis']); ?>

        </p>

        <div style="line-height: 1.8; margin-top: 20px; color: #444; text-align: left;">
            
            <p><?php echo e($post['konten']); ?></p> 
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ardy\resources\views/singleberita.blade.php ENDPATH**/ ?>