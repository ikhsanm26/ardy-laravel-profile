<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title><?php echo $__env->yieldContent('title', 'Aplikasi Profil Laravel'); ?></title>

    <style>
        /* CSS GLOBAL (Dari Profil, Kontak, dan Struktur Dasar) */
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 0 0 70px 0; /* Jarak untuk Footer */
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 20px;
            text-align: center;
            min-height: 400px;
        }
        
        /* CSS NAVBAR */
        .navbar { background-color: #333; overflow: hidden; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); }
        .navbar a { float: left; display: block; color: #f2f2f2; text-align: center; padding: 14px 16px; text-decoration: none; font-size: 17px; }
        .navbar a:hover { background-color: #ddd; color: black; }
        .navbar a.active { background-color: #007bff; color: white; }
        
        /* CSS FOOTER */
        .footer { background-color: #333; color: #f2f2f2; text-align: center; padding: 15px 0; position: fixed; bottom: 0; width: 100%; box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.2); }
        .footer p { margin: 0; font-size: 0.9em; }
        
        /* CSS Notifikasi (Sukses/Error Form) */
        .alert-success { max-width: 600px; margin: 10px auto; padding: 10px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: .25rem; text-align: center; }
        .alert-error { max-width: 600px; margin: 10px auto; padding: 10px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: .25rem; }
        .alert-error ul { list-style: none; padding: 0; margin: 0; text-align: left; }
    </style>
</head>
<body>
    
    
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if(session('success')): ?>
        <div class="alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert-error">
            <ul style="list-style: none; padding: 0; margin: 0; text-align: left;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    
    <main>
        
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\ardy\resources\views/layouts/app.blade.php ENDPATH**/ ?>