<style>
    /* CSS untuk Navigasi Bar */
    .navbar {
        background-color: #333;
        overflow: hidden;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        margin-bottom: 20px;
    }
    .navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 17px;
    }
    .navbar a:hover {
        background-color: #ddd;
        color: black;
    }
    .navbar a.active {
        background-color: #007bff;
        color: white;
    }
</style>

<div class="navbar">
    
    
    <a href="<?php echo e(url('/')); ?>" class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">Home</a>
    
    
    <a href="<?php echo e(url('/profil')); ?>" class="<?php echo e(Request::is('profil') ? 'active' : ''); ?>">Profil Saya</a>
    
    
    <a href="<?php echo e(route('berita.index')); ?>" class="<?php echo e(Request::is('berita') || Request::is('berita/*') ? 'active' : ''); ?>">Berita</a> 
    
    
    <a href="<?php echo e(url('/kontak')); ?>" class="<?php echo e(Request::is('kontak') ? 'active' : ''); ?>">Hubungi Saya</a>

    
    
    <a href="<?php echo e(route('mahasiswa')); ?>" class="<?php echo e(Request::is('mahasiswa*') ? 'active' : ''); ?>">Mahasiswa</a>

</div><?php /**PATH C:\laragon\www\ardy\resources\views/components/navbar.blade.php ENDPATH**/ ?>