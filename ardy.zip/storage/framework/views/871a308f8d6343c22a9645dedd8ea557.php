

<?php $__env->startSection('title', 'Daftar Berita Terbaru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="max-width: 800px; text-align: left;">
        <h1 style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid #007bff; padding-bottom: 5px;">Daftar Berita Unimus</h1>
        
        
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="border: 1px solid #ccc; padding: 15px; margin-bottom: 15px; border-radius: 8px;">
                <h2 style="color: #333; margin-top: 0; margin-bottom: 5px;"><?php echo e($post['judul']); ?></h2>
                <p style="font-size: 0.9em; color: #777;">Ditulis oleh <?php echo e($post['penulis']); ?></p>
                
                
                <a href="<?php echo e(route('berita.single', $post['slug'])); ?>" style="color: #007bff; text-decoration: none; font-weight: bold;">Baca Selengkapnya</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="text-align: center; color: #777;">Belum ada berita yang tersedia saat ini.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ardy\resources\views/berita.blade.php ENDPATH**/ ?>