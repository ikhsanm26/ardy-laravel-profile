@extends('layouts.main')

@section('content')
    <h1>{{ $title }}</h1>
    <p>Ini adalah halaman data mahasiswa.</p>
@endsection