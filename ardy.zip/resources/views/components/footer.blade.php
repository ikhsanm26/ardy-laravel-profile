<div class="footer">
    <p>&copy; {{ date('Y') }} Ardy Iksan Maulana. Semua Hak Dilindungi.</p>
    <p>
        <a href="{{ route('kontak.index') }}" style="color: #007bff; text-decoration: none;">Hubungi Saya</a>
    </p>
</div>